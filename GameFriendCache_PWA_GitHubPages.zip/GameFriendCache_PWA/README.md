# GameFriendCache PWA

GitHub Pagesで公開するための2つの変換アプリです。

## 構成
- `txt-converter/` : GameFriendCache.bin → TXT
- `bin-converter/` : TXT → GameFriendCache.bin

それぞれ独立したPWAとして、ホーム画面への追加とオフライン起動に対応します。

## GitHub Pagesで公開
1. このZIPを展開して、全ファイルをGitHubリポジトリのルートへアップロードします。
2. GitHubの **Settings → Pages** を開きます。
3. **Deploy from a branch** を選択し、`main` ブランチの `/ (root)` を指定して保存します。
4. 公開後、次のURLでアクセスします（`<ユーザー名>` と `<リポジトリ名>` は置き換え）。
   - `https://<ユーザー名>.github.io/<リポジトリ名>/txt-converter/`
   - `https://<ユーザー名>.github.io/<リポジトリ名>/bin-converter/`

## PWAのインストール
HTTPSで公開した各URLをChrome / Edge等で開き、ブラウザーの「アプリをインストール」または「ホーム画面に追加」を選択します。インストールボタンはブラウザーがインストール可能と判断した場合に表示されます。

## オフラインと更新
各アプリのService WorkerがHTML、manifest、アイコンをキャッシュします。初回アクセス時はインターネット接続が必要です。更新時は `sw.js` のキャッシュ名末尾のバージョン（`v1`）を `v2` などに変更して公開してください。ブラウザーが新しいService Workerを取得するとキャッシュが更新されます。

## ファイル処理と互換性
BIN/TXT変換はブラウザー内で実行され、ファイルを外部サーバーへ送信しません。BIN生成側はGZIP圧縮JSONを出力しますが、ゲーム独自の追加メタデータ・圧縮条件・整合性検証がある場合、ゲームでの完全互換性は保証されません。
